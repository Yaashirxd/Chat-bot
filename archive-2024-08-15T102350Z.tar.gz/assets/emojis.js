/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  //commands/config/247
  247: {
    247: "<:247:1270681384247099493>",
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    off: "<:ndisable:1270681389808877643>",
    on: "<:nenable:1270681391108984863>",
  },


  //commands/config/config
  config: {
    cog: "<:nsetting:1270694081957200055>",
    off: "<:ndisable:1270681389808877643>",
    on: "<:nenable:1270681391108984863>",
    point: "<a:reddot_:1270694081269596160>",
  },

  //commands/config/ignore
  ignore: {
    cog: "<:nsetting:1270694081957200055>",
    rem: "<:ndisable:1270681389808877643>",
    add: "<:nenable:1270681391108984863>",
    point: "<a:reddot_:1270694081269596160>",
    no: "<:nwrong:1270681388865032192>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/config/premium
  premium: {
    admin: "<:Admin:1270696262018138176> ",
    bell: "<:eg_notification:1270681386113564672> ",
    free: "<:free:1270695456090886205> ",
    rich: "<:nitro:1270695456942460929>",
    danger: "<:danger:1270695458209136640>",
    diamond: "<a:premium:1270695623296811008> ",
      info: "<:info:1270724171437178891>",
  },

  //commands/config/profile
  profile: {
    own: "<:zz_os:1270736079443726356>",
    admin: "<:Admin:1270696262018138176>",
    supporter: "<a:early_supporter:1270735637104033842>",
    premium: "<a:premium:1270695623296811008>",
    user: "<:MekoUser:1270697299156275232>",
  },

  //commands/config/redeem
  redeem: {
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    on: "<:nenable:1270681391108984863>",
    point: "<a:reddot_:1270694081269596160>",
    premium: "<a:premium:1270695623296811008>",
  },

  /////////////////////////////////////////////////////

  //commands/filter/filter
  enhance: {
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  optimize: {
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/filter/filter
  equalizer: {
    bell: "<:eg_notification:1270681386113564672>",
    cog: "<:nsetting:1270694081957200055>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/filter/equalizer
  filter: {
    cog: "<:nsetting:1270694081957200055>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  /////////////////////////////////////////////////////


  //commands/information/help

  help: {
    infoo: "<:info:1270724171437178891>",
    home: "<:eg_home:1270699840057380885>",
    music: "<:nmusic:1270699840879202358>",
    config: "<:eg_wrench:1270699842204602451>",
    filter: "<:eg_fire:1270699843181871146>",
    information: "<:nquestion:1270699844230451212>",
    extra: "<:ndevelopers:1270699845417435138>",
  },

  //commands/information/invite
  invite: {
    bell: "<:eg_notification:1270681386113564672>",
  },

  //commands/information/notice
  notice: {
    no: "<:nwrong:1270681388865032192>",
    yes: "<:tick_icon:1270694949666422797>",
    bug: "<:bug:1189086333617049720>",
  },

  //commands/information/ping
  ping: {
    link: "<:link:1270786350345359483> ",
    cool: "<:uptime:1270681387627970622> ",
    message: "<:message:1270786351649919072>",
    data: "<:dir:1270786353004544060>",
    node: "<:connect:1270786354237935676>",
  },

  //commands/information/report
  report: {
    bell: "<:eg_notification:1270681386113564672>",
    bug: "<:bug:1189086333617049720>",
    danger: "<:danger:1270695458209136640>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/information/stats
  stats: {
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    info: "<:info:1270724171437178891>",
    basic: "<a:early_supporter:1270735637104033842>",
    team: "<:zz_os:1270735750186532914>",
  },

  //commands/information/support
  support: {
    support: "<:nquestion:1270699844230451212>",
  },

  //commands/information/vote
  vote: {
    vote: "<:nquestion:1270699844230451212>",
  },

  /////////////////////////////////////////////////////

  //commands/music/autoplay
  autoplay: {
    autoplay: "<:autoplay:1270702143887769660>",
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    off: "<:ndisable:1270681389808877643>",
    on: "<:nenable:1270681391108984863>",
  },

  //commands/music/clear
  clear: {
    bell: "<:eg_notification:1270681386113564672>",
    cog: "<:nsetting:1270694081957200055>",
    list: "<:queue:1270702844445589545>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/music/grab
  grab: {
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
    cool: "<:uptime:1270681387627970622>",
    user: "<:MekoUser:1270697299156275232>",
  },

  //commands/music/join
  join: {
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    on: "<:nenable:1270681391108984863>",
    warn: "<:danger:1270695458209136640>",
  },

  //commands/music/leave
  leave: {
    cool: "<:uptime:1270681387627970622>",
    off: "<:ndisable:1270681389808877643>",
  },

  rejoin: {
    cool: "<:uptime:1270681387627970622>",
    on: "<:nenable:1270681391108984863>",
  },

  //commands/music/loop
  loop: {
    loop: "<:loop:1270786906644549782>",
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    on: "<:nenable:1270681391108984863>",
    off: "<:ndisable:1270681389808877643>",
    no: "<:nwrong:1270681388865032192>",
    queue: "<:queue:1270702844445589545>",
    track: "<:nmusic:1270699840879202358>",
  },

  //commands/music/nowPlaying
  nowplaying: {},

  //commands/music/pause
  pause: {
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/music/play
  play: {
    bell: "<:eg_notification:1270681386113564672>",
    warn: "<:danger:1270695458209136640>",
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
    search: "<:search:1270788048459661375>",
  },

  //commands/music/previous
  previous: {
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/music/queue
  queue: {
    cool: "<:uptime:1270681387627970622>",
  },

  //commands/music/radio
  radio: {
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    radio: "<:radio:1270788629119242312>",
    support: "<:nquestion:1270699844230451212>",
    warn: "<:danger:1270695458209136640>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/music/remove
  remove: {
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/music/resume
  resume: {
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/music/search
  search: {
    yes: "<:tick_icon:1270694949666422797>",
    warn: "<:danger:1270695458209136640>",
    no: "<:nwrong:1270681388865032192>",
    youtube: "<:youtube:1270789484841013342>",
    soundcloud: "<:soundcloud:1270789485759828141>",
    spotify: "<:spotify:1270789486799884290>",
    search: "<:search:1270788048459661375>",
    track: "<:nmusic:1270699840879202358>",
  },

  //commands/music/seek
  seek: {
    bell: "<:eg_notification:1270681386113564672>",
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/music/shuffle
  shuffle: {
    yes: "<:tick_icon:1270694949666422797>",
  },

  similar: {
    yes: "<:tick_icon:1270694949666422797>",
    warn: "<:danger:1270695458209136640>",
    no: "<:nwrong:1270681388865032192>",
    youtube: "<:youtube:1270789484841013342>",
    soundcloud: "<:soundcloud:1270789485759828141>",
    spotify: "<:spotify:1270789486799884290>",
    search: "<:search:1270788048459661375>",
    track: "<:nmusic:1270699840879202358>",
  },

  //commands/music/skip
  skip: {
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  //commands/music/stop
  stop: {
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/music/volume
  volume: {
    bell: "<:volumeee2:1270791146985095199>",
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },

  /////////////////////////////////////////////////////

  //commands/owner/add
  add: {
    admin: "<:Admin:1270696262018138176>",
    bell: "<:eg_notification:1270681386113564672>",
    no: "<:nwrong:1270681388865032192>",
    on: "<:nenable:1270681391108984863>",
    user: "<:MekoUser:1270697299156275232>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/owner/backup
  backup: {
    cool: "<:uptime:1270681387627970622>",
    yes: "<:tick_icon:1270694949666422797>",
    no: "<:nwrong:1270681388865032192>",
  },


  //commands/owner/list
  list: {
    bell: "<:eg_notification:1270681386113564672>",
    no: "<:nwrong:1270681388865032192>",
    cool: "<:uptime:1270681387627970622>",
    user: "<:MekoUser:1270697299156275232>",
    list: "<:list:1270792826254524606>",
  },

  //commands/owner/panel
  panel: {
    cool: "<:uptime:1270681387627970622>",
  },


  //commands/owner/reload
  reload: {},

  //commands/owner/restart
  restart: {
    bell: "<:eg_notification:1270681386113564672>",
    cool: "<:uptime:1270681387627970622>",
    no: "<:nwrong:1270681388865032192>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  //commands/owner/revoke
  revoke: {
    admin: "<:Admin:1270696262018138176>",
    bell: "<:eg_notification:1270681386113564672>",
    no: "<:nwrong:1270681388865032192>",
    on: "<:nenable:1270681391108984863>",
    off: "<:ndisable:1270681389808877643>",
    user: "<:MekoUser:1270697299156275232>",
    yes: "<:tick_icon:1270694949666422797>",
  },

  /////////////////////////////////////////////////////

  //stat cmd (bcevl + global)
  cog: "<:nsetting:1270694081957200055>",
  free: "<:free:1270695456090886205>",
  user: "<:MekoUser:1270697299156275232>",

  //global
  point: "<a:reddot_:1270694081269596160>",
  king: "<:zz_os:1270735750186532914>",
  bell: "<:eg_notification:1270681386113564672>",
  cool: "<:uptime:1270681387627970622>",
  warn: "<:danger:1270695458209136640>",
  yes: "<:tick_icon:1270694949666422797>",
  no: "<:nwrong:1270681388865032192>",
  helpline: "<:nquestion:1270699844230451212>",
  message: "<:message:1270786351649919072>",
  free: "<:free:1270695456090886205>",
  new: "<:MekoUser:1270697299156275232>",
  admin: "<:Admin:1270696262018138176>",
  rad: "<:radio:1270788629119242312>",
  diamond: "<a:premium:1270695623296811008>",
};
